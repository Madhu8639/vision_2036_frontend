import NavDropdown from './NavDropdown';

const NavMenu = () => {
  const navItems = {
    institutions: [
      { to: '/institutions/register', label: 'Register' },
      { to: '/institutions/signin', label: 'Sign In' }
    ],
    students: [
      { to: '/students/register', label: 'Register' },
      { to: '/students/signin', label: 'Sign In' }
    ]
  };

  return (
    <nav className="hidden md:flex space-x-6">
      {Object.entries(navItems).map(([category, links]) => (
        <NavDropdown 
          key={category} 
          title={category.charAt(0).toUpperCase() + category.slice(1)} 
          links={links} 
        />
      ))}
    </nav>
  );
};

export default NavMenu;