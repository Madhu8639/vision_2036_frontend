import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Carousel } from './Carousel';
import { ParallaxSection } from './ParallaxSection';
import { RegistrationForm } from './RegistrationForm';

const StudentRegistration = () => {
  return (
    <div className="min-h-screen">
      <ParallaxSection />
      
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold text-center mb-8">Join Our Sports Community</h1>
        
        <div className="mb-12">
          <Carousel />
        </div>

        <div className="max-w-3xl mx-auto">
          <RegistrationForm />
        </div>
      </div>
    </div>
  );
};

export default StudentRegistration;